# Minimal Portfolio HTML Template

An HTML Template for a minimal portfolio. Made with Bootstrap and modernizr.js for great compatibility.